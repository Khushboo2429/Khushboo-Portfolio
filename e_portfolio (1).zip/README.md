
# Khushboo Naik - E-Portfolio

This is a personal e-portfolio website hosted on GitHub Pages.

## How to Deploy on GitHub Pages

1. Go to [GitHub](https://github.com/) and log in.
2. Create a **new repository** (e.g., `khushboo-portfolio`).
3. Upload all files from this ZIP folder.
4. Go to **Settings** > **Pages**.
5. Under **Source**, select **main branch** and save.
6. Your website will be live at `https://yourusername.github.io/khushboo-portfolio/`.

---

© 2025 Khushboo Naik
